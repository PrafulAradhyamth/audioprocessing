# Expectation-Maximization
Notebook with implementation and visualization of Gaussian Mixtures and the EM Algorithm. Based ob Chapter 9.2 of Christopher M. Bishop, Pattern recognition and machine learning, 2006
